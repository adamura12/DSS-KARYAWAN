-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 26, 2025 at 04:20 PM
-- Server version: 10.3.39-MariaDB-0ubuntu0.20.04.2
-- PHP Version: 8.3.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dimaswahyu_wp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(5) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3'),
(2, 'budi', '00dfc53ee86af02e742515cdcf075ed3');

-- --------------------------------------------------------

--
-- Table structure for table `alternatif`
--

CREATE TABLE `alternatif` (
  `id_alternatif` int(5) NOT NULL,
  `nama_alternatif` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `alternatif`
--

INSERT INTO `alternatif` (`id_alternatif`, `nama_alternatif`) VALUES
(28, 'Budi Santoso'),
(29, 'Siti Aminah'),
(30, 'Agus Wijaya'),
(31, 'Dewi Lestari'),
(32, 'Rudi Hartono'),
(33, 'Maya Putri'),
(34, 'Joko Santoso'),
(35, 'Ani Suryani'),
(36, 'Bayu Pratama'),
(37, 'Putri Indah'),
(38, 'Eko Wahyudi'),
(39, 'Nurul Hidayah'),
(40, 'Rizky Ramadhan'),
(41, 'Fajar Setiawan'),
(42, 'Shinta Dewi'),
(43, 'Yoga Pratama'),
(44, 'Dian Paramita'),
(45, 'Taufik Hidayat'),
(46, 'Citra Kirana'),
(47, 'Andi Rahman'),
(48, 'Lina Marlina'),
(49, 'Dimas Prayoga'),
(50, 'Vina Agustina'),
(51, 'Gita Putri'),
(52, 'Hadi Susanto'),
(53, 'Indah Permata'),
(54, 'Kevin Sanjaya'),
(55, 'Lisa Amelia'),
(56, 'Mochamad Rido'),
(57, 'Nia Ramadhani'),
(58, 'Pandu Kusuma'),
(59, 'Qonita Azzahra'),
(60, 'Raka Putra'),
(61, 'Salsabila Dewi'),
(62, 'Teguh Nugroho'),
(63, 'Umi Kalsum'),
(64, 'Vicky Prasetyo'),
(65, 'Wina Oktaviani'),
(66, 'Xavier Alexander'),
(67, 'Yuni Shara'),
(68, 'Zulfikar Ahmad'),
(69, 'Aisyah Putri'),
(70, 'Bagas Dwi'),
(71, 'Cindy Larasati'),
(72, 'Daffa Aditama'),
(73, 'Eka Cahyani'),
(74, 'Fahmi Rahman'),
(75, 'Gita Ayu'),
(76, 'Hendra Kurniawan'),
(77, 'Irene Anggraini');

-- --------------------------------------------------------

--
-- Table structure for table `hasil`
--

CREATE TABLE `hasil` (
  `id_hasil` int(11) NOT NULL,
  `id_alternatif` int(11) NOT NULL,
  `nilai` decimal(11,11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hasil`
--

INSERT INTO `hasil` (`id_hasil`, `id_alternatif`, `nilai`) VALUES
(28, 28, 0.02943529900),
(29, 29, 0.04074790400),
(30, 30, 0.03181465800),
(31, 31, 0.04299364900),
(32, 32, 0.03041023800),
(33, 33, 0.04717810000),
(34, 34, 0.02155080300),
(35, 35, 0.03568326100),
(36, 36, 0.02394602300),
(37, 37, 0.03873292300),
(38, 38, 0.03741041700),
(39, 39, 0.02745467800),
(40, 40, 0.04134999300),
(41, 41, 0.02625754600),
(42, 42, 0.03957976200),
(43, 43, 0.02339641800),
(44, 44, 0.03278895300),
(45, 45, 0.02293146500),
(46, 46, 0.03181465800),
(47, 47, 0.04170511400),
(48, 48, 0.03778375400),
(49, 49, 0.02345190700),
(50, 50, 0.03316770700),
(51, 51, 0.04419216500),
(52, 52, 0.03562652000),
(53, 53, 0.02745467800),
(54, 54, 0.04200686600),
(55, 55, 0.03278895300),
(56, 56, 0.02654449900),
(57, 57, 0.02980108600);

-- --------------------------------------------------------

--
-- Table structure for table `kriteria`
--

CREATE TABLE `kriteria` (
  `id_kriteria` int(5) NOT NULL,
  `kode_kriteria` varchar(5) NOT NULL,
  `nama_kriteria` varchar(50) NOT NULL,
  `bobot` int(5) NOT NULL,
  `tipe` enum('cost','benefit') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `kriteria`
--

INSERT INTO `kriteria` (`id_kriteria`, `kode_kriteria`, `nama_kriteria`, `bobot`, `tipe`) VALUES
(1, 'K1', 'Disiplin', 3, 'benefit'),
(2, 'K2', 'Komunikasi', 5, 'benefit'),
(3, 'K3', 'Skill Teknis', 4, 'benefit'),
(4, 'K4', 'Kerja Tim', 5, 'benefit'),
(5, 'K5', 'Kreativitas', 5, 'benefit');

-- --------------------------------------------------------

--
-- Table structure for table `opt_alternatif`
--

CREATE TABLE `opt_alternatif` (
  `id` int(11) NOT NULL,
  `id_alternatif` int(5) NOT NULL,
  `id_kriteria` int(5) NOT NULL,
  `id_subkriteria` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Tabel ini digunakan agar kriteria nya bisa dinamis';

--
-- Dumping data for table `opt_alternatif`
--

INSERT INTO `opt_alternatif` (`id`, `id_alternatif`, `id_kriteria`, `id_subkriteria`) VALUES
(136, 28, 1, 269),
(137, 28, 2, 273),
(138, 28, 3, 279),
(139, 28, 4, 285),
(140, 28, 5, 286),
(141, 29, 1, 268),
(142, 29, 2, 275),
(143, 29, 3, 280),
(144, 29, 4, 284),
(145, 29, 5, 288),
(146, 30, 1, 267),
(147, 30, 2, 272),
(148, 30, 3, 280),
(149, 30, 4, 283),
(150, 30, 5, 289),
(151, 31, 1, 269),
(152, 31, 2, 274),
(153, 31, 3, 278),
(154, 31, 4, 285),
(155, 31, 5, 290),
(156, 32, 1, 270),
(157, 32, 2, 275),
(158, 32, 3, 279),
(159, 32, 4, 282),
(160, 32, 5, 288),
(161, 33, 1, 269),
(162, 33, 2, 275),
(163, 33, 3, 280),
(164, 33, 4, 285),
(165, 33, 5, 289),
(166, 34, 1, 267),
(167, 34, 2, 273),
(168, 34, 3, 277),
(169, 34, 4, 283),
(170, 34, 5, 286),
(171, 35, 1, 268),
(172, 35, 2, 272),
(173, 35, 3, 279),
(174, 35, 4, 284),
(175, 35, 5, 290),
(176, 36, 1, 266),
(177, 36, 2, 275),
(178, 36, 3, 278),
(179, 36, 4, 281),
(180, 36, 5, 289),
(181, 37, 1, 268),
(182, 37, 2, 274),
(183, 37, 3, 280),
(184, 37, 4, 284),
(185, 37, 5, 288),
(186, 38, 1, 269),
(187, 38, 2, 273),
(188, 38, 3, 277),
(189, 38, 4, 285),
(190, 38, 5, 290),
(191, 39, 1, 267),
(192, 39, 2, 275),
(193, 39, 3, 279),
(194, 39, 4, 283),
(195, 39, 5, 286),
(196, 40, 1, 268),
(197, 40, 2, 274),
(198, 40, 3, 280),
(199, 40, 4, 284),
(200, 40, 5, 289),
(201, 41, 1, 266),
(202, 41, 2, 272),
(203, 41, 3, 278),
(204, 41, 4, 285),
(205, 41, 5, 288),
(206, 42, 1, 267),
(207, 42, 2, 275),
(208, 42, 3, 279),
(209, 42, 4, 283),
(210, 42, 5, 290),
(211, 43, 1, 266),
(212, 43, 2, 273),
(213, 43, 3, 280),
(214, 43, 4, 281),
(215, 43, 5, 289),
(216, 44, 1, 268),
(217, 44, 2, 274),
(218, 44, 3, 277),
(219, 44, 4, 284),
(220, 44, 5, 288),
(221, 45, 1, 269),
(222, 45, 2, 275),
(223, 45, 3, 279),
(224, 45, 4, 281),
(225, 45, 5, 286),
(226, 46, 1, 267),
(227, 46, 2, 272),
(228, 46, 3, 280),
(229, 46, 4, 283),
(230, 46, 5, 289),
(231, 47, 1, 268),
(232, 47, 2, 275),
(233, 47, 3, 278),
(234, 47, 4, 284),
(235, 47, 5, 290),
(236, 48, 1, 269),
(237, 48, 2, 273),
(238, 48, 3, 279),
(239, 48, 4, 285),
(240, 48, 5, 288),
(241, 49, 1, 270),
(242, 49, 2, 274),
(243, 49, 3, 280),
(244, 49, 4, 282),
(245, 49, 5, 286),
(246, 50, 1, 267),
(247, 50, 2, 275),
(248, 50, 3, 277),
(249, 50, 4, 283),
(250, 50, 5, 289),
(251, 51, 1, 269),
(252, 51, 2, 275),
(253, 51, 3, 280),
(254, 51, 4, 285),
(255, 51, 5, 288),
(256, 52, 1, 268),
(257, 52, 2, 272),
(258, 52, 3, 278),
(259, 52, 4, 285),
(260, 52, 5, 290),
(261, 53, 1, 267),
(262, 53, 2, 275),
(263, 53, 3, 279),
(264, 53, 4, 283),
(265, 53, 5, 286),
(266, 54, 1, 269),
(267, 54, 2, 273),
(268, 54, 3, 280),
(269, 54, 4, 285),
(270, 54, 5, 289),
(271, 55, 1, 268),
(272, 55, 2, 274),
(273, 55, 3, 277),
(274, 55, 4, 284),
(275, 55, 5, 288),
(276, 56, 1, 266),
(277, 56, 2, 275),
(278, 56, 3, 279),
(279, 56, 4, 281),
(280, 56, 5, 290),
(281, 57, 1, 267),
(282, 57, 2, 272),
(283, 57, 3, 280),
(284, 57, 4, 283),
(285, 57, 5, 288),
(286, 58, 1, 269),
(287, 58, 2, 275),
(288, 58, 3, 278),
(289, 58, 4, 285),
(290, 58, 5, 289),
(291, 59, 1, 268),
(292, 59, 2, 273),
(293, 59, 3, 279),
(294, 59, 4, 284),
(295, 59, 5, 286),
(296, 60, 1, 270),
(297, 60, 2, 275),
(298, 60, 3, 280),
(299, 60, 4, 282),
(300, 60, 5, 288),
(301, 61, 1, 269),
(302, 61, 2, 272),
(303, 61, 3, 277),
(304, 61, 4, 285),
(305, 61, 5, 290),
(306, 62, 1, 267),
(307, 62, 2, 275),
(308, 62, 3, 279),
(309, 62, 4, 283),
(310, 62, 5, 289),
(311, 63, 1, 268),
(312, 63, 2, 274),
(313, 63, 3, 280),
(314, 63, 4, 284),
(315, 63, 5, 288),
(316, 64, 1, 269),
(317, 64, 2, 273),
(318, 64, 3, 277),
(319, 64, 4, 285),
(320, 64, 5, 286),
(321, 65, 1, 267),
(322, 65, 2, 275),
(323, 65, 3, 279),
(324, 65, 4, 283),
(325, 65, 5, 290),
(326, 66, 1, 266),
(327, 66, 2, 274),
(328, 66, 3, 280),
(329, 66, 4, 281),
(330, 66, 5, 289),
(331, 67, 1, 268),
(332, 67, 2, 272),
(333, 67, 3, 278),
(334, 67, 4, 284),
(335, 67, 5, 286),
(336, 68, 1, 269),
(337, 68, 2, 275),
(338, 68, 3, 279),
(339, 68, 4, 285),
(340, 68, 5, 288),
(341, 69, 1, 267),
(342, 69, 2, 273),
(343, 69, 3, 280),
(344, 69, 4, 283),
(345, 69, 5, 290),
(346, 70, 1, 268),
(347, 70, 2, 275),
(348, 70, 3, 277),
(349, 70, 4, 284),
(350, 70, 5, 287),
(351, 71, 1, 269),
(352, 71, 2, 272),
(353, 71, 3, 279),
(354, 71, 4, 285),
(355, 71, 5, 286),
(356, 72, 1, 270),
(357, 72, 2, 275),
(358, 72, 3, 280),
(359, 72, 4, 282),
(360, 72, 5, 289),
(361, 73, 1, 267),
(362, 73, 2, 274),
(363, 73, 3, 278),
(364, 73, 4, 283),
(365, 73, 5, 290),
(366, 74, 1, 269),
(367, 74, 2, 275),
(368, 74, 3, 277),
(369, 74, 4, 285),
(370, 74, 5, 288),
(371, 75, 1, 268),
(372, 75, 2, 272),
(373, 75, 3, 280),
(374, 75, 4, 284),
(375, 75, 5, 286),
(376, 76, 1, 266),
(377, 76, 2, 275),
(378, 76, 3, 279),
(379, 76, 4, 281),
(380, 76, 5, 289),
(381, 77, 1, 267),
(382, 77, 2, 273),
(383, 77, 3, 280),
(384, 77, 4, 283),
(385, 77, 5, 290);

-- --------------------------------------------------------

--
-- Table structure for table `subkriteria`
--

CREATE TABLE `subkriteria` (
  `id_subkriteria` int(5) NOT NULL,
  `id_kriteria` int(5) NOT NULL,
  `nama_subkriteria` varchar(50) NOT NULL,
  `bobot` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `subkriteria`
--

INSERT INTO `subkriteria` (`id_subkriteria`, `id_kriteria`, `nama_subkriteria`, `bobot`) VALUES
(266, 1, 'sangat buruk', 1),
(267, 1, 'cukup', 3),
(268, 1, 'baik', 4),
(269, 1, 'sangat baik', 5),
(270, 1, 'buruk', 2),
(271, 2, 'sangat buruk', 1),
(272, 2, 'buruk', 2),
(273, 2, 'cukup', 3),
(274, 2, 'baik', 4),
(275, 2, 'sangat baik', 5),
(276, 3, 'sangat buruk', 1),
(277, 3, 'buruk', 2),
(278, 3, 'cukup', 3),
(279, 3, 'baik', 4),
(280, 3, 'sangat baik', 5),
(281, 4, 'sangat buruk', 1),
(282, 4, 'buruk', 2),
(283, 4, 'cukup', 3),
(284, 4, 'baik', 4),
(285, 4, 'sangat baik', 5),
(286, 5, 'sangat buruk', 1),
(287, 5, 'buruk', 2),
(288, 5, 'cukup', 3),
(289, 5, 'baik', 4),
(290, 5, 'sangat baik', 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `alternatif`
--
ALTER TABLE `alternatif`
  ADD PRIMARY KEY (`id_alternatif`);

--
-- Indexes for table `hasil`
--
ALTER TABLE `hasil`
  ADD PRIMARY KEY (`id_hasil`),
  ADD KEY `id_alternatif` (`id_alternatif`);

--
-- Indexes for table `kriteria`
--
ALTER TABLE `kriteria`
  ADD PRIMARY KEY (`id_kriteria`);

--
-- Indexes for table `opt_alternatif`
--
ALTER TABLE `opt_alternatif`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_alternatif` (`id_alternatif`),
  ADD KEY `id_kriteria` (`id_kriteria`),
  ADD KEY `id_subkriteria` (`id_subkriteria`);

--
-- Indexes for table `subkriteria`
--
ALTER TABLE `subkriteria`
  ADD PRIMARY KEY (`id_subkriteria`),
  ADD KEY `id_kriteria` (`id_kriteria`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `alternatif`
--
ALTER TABLE `alternatif`
  MODIFY `id_alternatif` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `hasil`
--
ALTER TABLE `hasil`
  MODIFY `id_hasil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `kriteria`
--
ALTER TABLE `kriteria`
  MODIFY `id_kriteria` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `opt_alternatif`
--
ALTER TABLE `opt_alternatif`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=386;

--
-- AUTO_INCREMENT for table `subkriteria`
--
ALTER TABLE `subkriteria`
  MODIFY `id_subkriteria` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=294;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `hasil`
--
ALTER TABLE `hasil`
  ADD CONSTRAINT `hasil_ibfk_1` FOREIGN KEY (`id_alternatif`) REFERENCES `alternatif` (`id_alternatif`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `opt_alternatif`
--
ALTER TABLE `opt_alternatif`
  ADD CONSTRAINT `opt_alternatif_ibfk_1` FOREIGN KEY (`id_alternatif`) REFERENCES `alternatif` (`id_alternatif`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `opt_alternatif_ibfk_2` FOREIGN KEY (`id_kriteria`) REFERENCES `kriteria` (`id_kriteria`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `opt_alternatif_ibfk_3` FOREIGN KEY (`id_subkriteria`) REFERENCES `subkriteria` (`id_subkriteria`) ON DELETE SET NULL ON UPDATE NO ACTION;

--
-- Constraints for table `subkriteria`
--
ALTER TABLE `subkriteria`
  ADD CONSTRAINT `subkriteria_ibfk_1` FOREIGN KEY (`id_kriteria`) REFERENCES `kriteria` (`id_kriteria`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
