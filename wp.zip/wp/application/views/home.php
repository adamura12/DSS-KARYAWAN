<?php $this->load->view('template/header'); ?>

<div class="box box-success">
    <!-- <div style="display: flex; justify-content: center; align-items: center; height: 100vh;"> -->
        <div class="box-header with-border" style="text-align: center;">
            <h3 class="box-title"><h3>Selamat Datang</h3></h3>
        </div>
        <div class="box-body" style="text-align: center;">
            <img src="assets/images/logo.jpg" style="width: 300px;">
            <h3>Selamat datang di aplikasi SPK Pemilihan Karyawan Terbaik menggunakan metode WP </h3>
            <h3>Silahkan pilih menu disamping untuk melakukan pengolahan data</h3>
        </div>
    <!-- </div> -->
</div>

<?php $this->load->view('template/footer'); ?> 